package com.canvas.view.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.canvas.view.R;

public class MainActivity extends AppCompatActivity {

    SimpleDrawingView canvasView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        canvasView = (SimpleDrawingView) findViewById(R.id.simpleDrawingView1);
        canvasView.setBitmapUrl("http://cdn-poster-bgllabs.vsscloud.in/VOD/2_3/shrek.jpg");
    }
}

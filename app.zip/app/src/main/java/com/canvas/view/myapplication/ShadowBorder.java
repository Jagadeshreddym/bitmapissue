package com.canvas.view.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class ShadowBorder extends View {
    // setup initial color
    private final int paintColor = Color.WHITE;
    private Paint drawPaint;
    private Context context;
    private int mStrokeWidth;
    private int mShadeStrokeWidth;
    private int mWidth;
    private int mHeight;
    private SimpleDrawingView.KidsEventScrollerItemDisplayType mDisplayType;
    private int mColor;
    private boolean mSetAlpha;
    private int xPoint = 30;
    private int yPoint = 30;

    public enum KidsEventScrollerItemDisplayType {
        RECTANGLE, CIRCLE
    }



    public ShadowBorder(Context context) {
        super(context);
    }

    public ShadowBorder(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ShadowBorder(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


    // Setup paint with color and stroke styles
    private void setupPaint() {
        drawPaint = new Paint();
        drawPaint.setColor(paintColor);
        drawPaint.setAntiAlias(true);
        drawPaint.setStrokeWidth(mStrokeWidth);
        drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);

    }

    @Override
    protected void onDraw(Canvas canvas) {

        this.context = context;
        setFocusable(true);
        setFocusableInTouchMode(true);
        setupPaint();

        drawPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        // draw Shader
        final Paint paint1 = new Paint();
        if(mSetAlpha)
        {
            final Rect rect1 = new Rect(mShadeStrokeWidth, (mShadeStrokeWidth * 2), mWidth, mHeight+(mShadeStrokeWidth * 2));
            final RectF rectF1 = new RectF(rect1);
            paint1.setColor(Color.BLACK);
            paint1.setAlpha(90);
            paint1.setStyle(Paint.Style.STROKE);
            paint1.setStrokeWidth(mShadeStrokeWidth);
            canvas.drawRoundRect(rectF1, xPoint, yPoint, paint1);
        }else
        {
            final Rect rect1 = new Rect(mShadeStrokeWidth, mShadeStrokeWidth, mWidth , mHeight );
            final RectF rectF1 = new RectF(rect1);
            paint1.setColor(Color.WHITE);
            paint1.setStyle(Paint.Style.STROKE);
            paint1.setStrokeWidth(mShadeStrokeWidth);
            canvas.drawRoundRect(rectF1, xPoint, yPoint, paint1);
        }


    }

    public void setStokeWidth(int width, int height, int strokeWidth, int shadeStrokeWidth, int color, boolean setAlpha)
    {
        mStrokeWidth = strokeWidth;
        mShadeStrokeWidth = shadeStrokeWidth;

        mWidth = width;
        mHeight = height;
        mColor = color;
        mSetAlpha = setAlpha;
    }


}

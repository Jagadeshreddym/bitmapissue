package com.canvas.view.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


import com.bumptech.glide.Glide;
import com.canvas.view.R;

import java.util.List;



public class kidsEventScrollerAdapter extends RecyclerView.Adapter<kidsEventScrollerAdapter.KidsItemViewHolder> {

    private RecyclerViewClickListener mListener;
    List<String> mDmEvent = null;
    Context mContext;
    Object mFilter;
    boolean mIsFullContent;

    public kidsEventScrollerAdapter(Context context, List<String> event, Object filter, boolean isFullContent, RecyclerViewClickListener listener) {
        mContext = context;
        this.mDmEvent = event;
        mListener = listener;
        mIsFullContent = isFullContent;

    }

    @Override
    public KidsItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inflator_view, parent, false);

        //View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.kids_swimlane_item,parent, false);

        // final SimpleDrawingView view = new SimpleDrawingView(mContext, SimpleDrawingView.KidsEventScrollerItemDisplayType.RECTANGLE, 200,300,10,10,20);
        // RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(MainActivity.width+(MainActivity.barderWidth*2) , MainActivity.height +(MainActivity.barderWidth*2) + MainActivity.maskWidth);
        // view.setLayoutParams(params);

       /* CircularImageView mImageView = new CircularImageView(mContext);
        mImageView.setBorderColor(Color.WHITE);
        mImageView.setBorderWidth(mBarderWidth);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mPosterWidth, mPosterHeight);
        mImageView.setLayoutParams(layoutParams);*/


        return new KidsItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(kidsEventScrollerAdapter.KidsItemViewHolder holder, int position) {

        String url = mDmEvent.get(position);
       /* Glide.with(mContext).load(url)
                .into(holder.poster);*/

        int mBarderWidth = 20;
        int mShadeWidth = 10;

        int mPosterWidth = 1000;
        int mPosterHeight = 1000;

        int mItemWidth = mPosterWidth + ((int)mBarderWidth * 2);
        int mItemHeight = mPosterHeight + ((int)mBarderWidth * 2) + (int)mShadeWidth;

        int mRectRadius = 40;

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mPosterWidth, mPosterHeight);
        holder.rectangleImage.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams layoutParamsMainLayout = new RelativeLayout.LayoutParams(mPosterWidth+100, mPosterHeight+100);
        holder.mShadowBorderColor.setLayoutParams(layoutParamsMainLayout);

        holder.mShadowBorder.setStokeWidth((mPosterWidth-mRectRadius),(mPosterHeight-(mRectRadius*2)),20,mRectRadius,Color.BLACK,true);
        holder.mShadowBorder.setLayoutParams(layoutParamsMainLayout);
        holder.mShadowBorderColor.setStokeWidth((mPosterWidth-mRectRadius),(mPosterHeight-mRectRadius),20,mRectRadius,Color.WHITE,false);

        holder.rectangleImage.setBorderColor(Color.TRANSPARENT);
        holder.rectangleImage.setBorderWidth(mBarderWidth);
        holder.rectangleImage.setRadius(mRectRadius);
        holder.rectangleImage.setRadius(mRectRadius);

        Glide.with(mContext)
                .load(Uri.parse(url)) //URI to image from local addressbook
                .asBitmap()
                .into(holder.rectangleImage);

    }

    @Override
    public int getItemCount() {
        return mDmEvent.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    class KidsItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private RecyclerViewClickListener mListener;

        private View itemView = null;
        private CircularImageView poster = null;
        public RoundedImageView rectangleImage,rectangleImageShadow;
        public CircularImageView circularImage;
        public ShadowBorder mShadowBorder;
        public ShadowBorder mShadowBorderColor;
        public RelativeLayout mRelativeMainView;


        KidsItemViewHolder(final View view) {
            super(view);
            itemView = view;
            rectangleImage = (RoundedImageView) view.findViewById(R.id.rectangular_view);
            circularImage = (CircularImageView) view.findViewById(R.id.circle_view);
            mShadowBorder = (ShadowBorder)view.findViewById(R.id.shadow);
            mShadowBorderColor = (ShadowBorder)view.findViewById(R.id.shadow_white);
            mRelativeMainView = (RelativeLayout)view.findViewById(R.id.main_view);

        }


        @Override
        public void onClick(View view) {
            mListener.onClick(view, mDmEvent.get(getAdapterPosition()));
        }

    }

    public interface RecyclerViewClickListener {

        void onClick(View view, Object eventData);
    }

}